# API Reconnaissance

|ID          |
|------------|
|WSTG-APIT-01|

## Summary

Reconnaissance is an important step in any pentesting engagement. This includes API pentesting. Reconnaissance significantly enhances the effectiveness of the testing process by gathering information about the API and developing an understanding of the target. This phase not only increases the likelihood of discovering critical security issues but also ensures a comprehensive evaluation of the APIs' security posture.

This guide has a section on [Information Gathering](../01-Information_Gathering/README.md) which can apply when auditing APIs. However, there are some differences. As security researchers, we often focus on specific areas and searching this guide for the sections that apply can be time consuming. To ensure the researcher has a single location to focus on APIs this section concentrates on those items that apply to APIs and provides references to supporting content elsewhere in the guide.

### API Types

APIs can be public or private.

#### Public APIs

Public APIs typically have their details published in a Swagger/OpenAPI document. Gaining access to this document is important to understand the attack surface. Equally important is finding older versions of this document that might show deprecated but still functional code that may have security vulnerabilities.

Keep in mind that this document, however well intentioned, may not be accurate, and also may not disclose the complete API.

Public APIs may also be documented on shared libraries or directories of APIs.

#### Private APIs

The visibility of private APIs depends on who the intended consumer is. An API can be private, but only accessible to subscribed clients (also known as `partners`) or only accessible to internal clients, such as other departments within the same company. Finding private APIs using reconnaissance techniques is also important. These APIs can be discovered using a number of techniques which we will discuss below.

## Test Objectives

- Find all API endpoints supported by the backend server code, documented or undocumented.
- Find all parameters for each endpoint supported by the backend server, documented or undocumented.
- Discover interesting data related to APIs in HTML and JavaScript sent to clients.

## How to Test

### Find the Documentation

In both public and private cases, the API documentation will be useful based on its level of quality and accuracy. Public API documentation is typically shared with everyone whereas private API documentation is only shared with the intended client. However, in both cases finding documentation, accidentally leaked or otherwise will be helpful in your investigation.

Regardless of the visibility of the API, searching for API documentation can find older, not-yet-published, or accidentally leaked API documentation. This documentation will be very helpful in understanding what attack surface the API exposes.

For time-boxed engagements, request machine-readable API artifacts from the customer as early as possible so testing tools can import or process them directly. Ask for OpenAPI definitions, legacy Swagger 2.0 specifications, and up-to-date request collections (for example [Postman](https://www.postman.com/) or [Bruno](https://www.usebruno.com/)). For non-REST APIs in scope (for example GraphQL), request schemas or exported schemas when introspection is disabled. Request replay definitions (for example [Hurl](https://hurl.dev/)) are also useful. If the API is older, WSDL or WADL files can appear as legacy artifacts in some environments. This is especially useful for private, internal, or newly deployed APIs where public documentation may not exist.

### API Directories

Alternative sources of API documentation can include API Directories, such as:

- GitHub in general
- [GitHub Public APIs Repository](https://github.com/public-apis/public-apis)
- [APIs.guru](https://apis.guru)
- [RapidAPI](https://rapidapi.com/)
- [PublicAPIs](https://publicapis.dev/) and [PublicAPIs](https://publicapis.io/)
- [Postman API Network](https://www.postman.com/explore)

### Looking in Well Known Places

If documentation is not readily apparent, then you can actively search the target for documentation based on a few obvious names or paths. These include:

- /api-docs
- /doc
- /swagger
- /swagger.json
- /openapi.json
- /.well-known/schema-discovery

### Robots.txt

`robots.txt` is a text file that site owners create to instruct web crawlers (such as search engine bots) on how to crawl and index their site. It is part of the Robots Exclusion Protocol (REP), which regulates how bots interact with sites.

This file may provide additional clues to path structure or API endpoints.

The [Information Gathering](../01-Information_Gathering/README.md) section refers to robots.txt in several cases including WSTG-INFO-01, WSTG-INFO-03, WSTG-INFO-05, and WSTG-INFO-08.

### GitDorking

If the application uses GitHub, GitLab, or other public facing Git based repositories then we can also search for any clues or sensitive content (also known as `GitDorking`). This information can include passwords, API keys, configuration files, and other confidential data that developers may accidentally or inadvertently commit to their repositories. Organizations can accidentally share sensitive code, sample, or test code that may provide clues to implementation details. The personal GitHub accounts of the target's employees may also accidentally release information that can provide clues.

### Browsing and Spidering the Application

Even if you have the API documentation browsing the application is a good idea. Documentation can be outdated, inaccurate, or incomplete.

Browsing the application with an intercepting proxy such as ZAP or Burp Suite records endpoints for later inspection. In addition, using their built-in spidering functionality, intercepting proxies can help generate a comprehensive list of endpoints. From the spidered URLs look for links with obvious API URL naming schemes. These include:

- `https://example.com/api/v1` (or v2 etc)  
- `https://example.com/graphql`

Or subdomains the applications may consume or depend upon:

- `https://api.example.com/api/v1`

It is important that the pentester attempts to exercise as much functionality in the application as possible. This is not only to generate a comprehensive list of endpoints but also to avoid issues with lazy loading and code splitting. In addition, your pentest engagement should include sample accounts at different privilege levels so that your browser and spidering can access and expose endpoints for as much functionality as possible.

Once completed, the endpoint information obtained from browsing and spidering of the application can help the pentester compose API documentation and collections using tools such as [Postman](https://www.postman.com/) and [Bruno](https://www.usebruno.com/). Request replay tools such as [Hurl](https://hurl.dev/) can then use that information to automate repeatable test flows. Some clients, such as Postman and Bruno, can also use pre-request and post-request scripts, which can help replay realistic flows when testing stateful APIs.

### Analyze Intercepted Requests

When auditing REST APIs, use an interception proxy to collect full HTTP requests. REST services utilize more than just URL parameters, so capturing the complete request body and headers is critical.

Analyze the collected requests to identify non-standard or hidden parameters:

- Identify HTTP headers that influence application behavior or resource selection.
- Determine if a URL segment has a repeating pattern across multiple URLs. Patterns containing dates, numbers, or identifier values may indicate a URL-embedded parameter. For example, in the URL `https://api.example.com/user/2026-10-03/profile`, the date segment may represent a parameter value.
- Identify structured parameter values formatted in JSON, XML, or other custom structures.
- Examine the final element of a URL. If it lacks a file extension, it may be a parameter.
- Look for highly varying URL segments. If a single segment changes frequently across hundreds of requests, it is more likely to represent a parameter value than a static path component.
- Verify suspected variable URL segments by setting them to an obviously invalid value. This applies to intermediate segments that look dynamic as well as terminal segments without file extensions. A routing-level `404` before application processing can indicate a static path segment. Application-generated `404` responses are not enough on their own to make that distinction. If the request reaches application logic and returns a resource-not-found or validation error, the segment may be application-routed and parameterized. Treat this as a heuristic and correlate the response source with observed routing behavior.

### Google Dorking

Using passive reconnaissance techniques such as Google Dorking with directives such as `site` and `inurl` allows us to tailor a search for common API keywords that the Google indexer may have found. Review [Conduct Search Engine Reconnaissance for Information Leakage](../01-Information_Gathering/01-Conduct_Search_Engine_Reconnaissance_for_Information_Leakage.md) for additional information.

Here are a few API specific examples:

`site:"mytargetsite.com" inurl:"/api"`

`inurl:apikey filetype:env`

Other keywords can include `"v1"`, `"api"`, `"graphql"`.

We can extend the Google Dorking to include subdomains of the target.

Wordlists are helpful here for a comprehensive list of common words used in APIs.

### Look Back, Way Back

In general APIs change over time. But deprecated or older version may still be operational either on purpose or by misconfiguration. These should also be tested as there is a good chance that they will contain vulnerabilities that newer versions have fixed. In addition, changes to APIs show newer features which may be less robust and therefore a good candidate for testing.

To discover older versions we can use the `Wayback machine` to help find older endpoints. A helpful tool know as TomNomNom's [WayBackUrls](https://github.com/tomnomnom/waybackurls) fetches all the URLs that the Wayback Machine knows about for a domain.

- [WayBackUrls](https://github.com/tomnomnom/waybackurls). Fetch all the URLs that the Wayback Machine knows about for a domain.
- [waymore](https://github.com/xnl-h4ck3r/waymore). Find way more from the Wayback Machine, Common Crawl, Alien Vault OTX, URLScan & VirusTotal.
- [gau](https://github.com/lc/gau). Fetch known URLs from AlienVault's Open Threat Exchange, the Wayback Machine, and Common Crawl.

### The Client-Side Application

An excellent source of API and other information is the HTML and JavaScript that the server sends to the client. Sometimes, the client application leaks sensitive information including APIs and secrets. The [Review Web Page Content for Information Leakage](../01-Information_Gathering/05-Review_Web_Page_Content_for_Information_Leakage.md) section has some general information for reviewing web content for leakage. Here we will expand to focus on reviewing the JavaScript content for API related secrets.

There are a variety of tools that we can use to help us extract sensitive information from JavaScript transmitted to the browser. These tools are typically based on one of two approaches: Regular Expressions or Abstract Syntax Trees (AST). Then there are generalized tools that help us organize or manage JS files for investigation by AST and Regular Expression tools.

Regular expression is more straightforward by searching JS or HTML content for known patterns. However, this approach can miss content not explicitly identified in the Regular Expression. Given the structure of some JS this approach can miss a lot. ASTs on the other hand are tree-like structures that represent the syntax of source code. Each node in the tree corresponds to a part of the code. For JavaScript, an AST breaks the code into basic components, allowing tools and compilers to understand and modify the code easily.

#### General Tools

1. [Uproot](https://github.com/0xDexter0us/uproot-JS). A BurpSuite plugin that saves any encountered JS files to disk. This helps extract the files for any analysis by command-line tools.
2. [OpenAPI Support](https://www.zaproxy.org/docs/desktop/addons/openapi-support/). This ZAP add-on allows you to spider and import OpenAPI (Swagger) definitions, versions 1.2, 2.0, and 3.0.
3. [OpenAPI Parser](https://github.com/aress31/openapi-parser). A BurpSuite plugin that parses OpenAPI documents into Burp Suite for automating OpenAPI-based APIs security assessments.

#### Regular Expression Tools

1. [JSParser](https://github.com/nahamsec/JSParser). A python 2.7 script using Tornado and JSBeautifier to parse relative URLs from JavaScript files.
2. [JSMiner](https://github.com/PortSwigger/js-miner). A BurpSuite plugin tries to find interesting stuff inside static files; mainly JavaScript and JSON files. This tool scans "passively" while crawling the application.
3. [JSpector](https://github.com/hisxo/JSpector). A BurpSuite plugin that passively crawls JavaScript files and automatically creates issues with URLs, endpoints and dangerous methods found on the JS files.
4. [Link Finder](https://github.com/GerbenJavado/LinkFinder). A python script that finds endpoints in JavaScript files.

#### AST Tools

1. [JSLuice](https://github.com/BishopFox/jsluice). A command-line tool that extracts URLs, paths, secrets, and other interesting data from JavaScript source code.

### Other Recon Tools

1. [Attack Surface Detector](https://github.com/secdec/attack-surface-detector-burp). A BurpSuite plugin that uses static code analyses to identify web app endpoints by parsing routes and identifying parameters.
2. [Param Miner](https://github.com/portswigger/param-miner). A BurpSuite plugin that identifies hidden, unlinked parameters.
3. [xnLinkFinder](https://github.com/xnl-h4ck3r/xnLinkFinder). A python tool used to discover endpoints, potential parameters, and a target specific wordlist for a given target.
4. [GAP](https://github.com/xnl-h4ck3r/GAP-Burp-Extension). Burp Extension to find potential endpoints, parameters, and generate a custom target wordlist.

### Server-Side Source Code

If you have access to the server-side source code, extract the endpoints from it. [OWASP Noir](https://owasp.org/projects/noir) parses the routing code of many web frameworks and lists every endpoint with its methods and parameters, including internal or deprecated APIs that no current client calls. See [Identify Application Entry Points](../01-Information_Gathering/06-Identify_Application_Entry_Points.md#owasp-noir) for a walkthrough of the tool.

For API testing, export the results as OpenAPI. This command writes an OpenAPI 3.0 document for every endpoint in the [OWASP RailsGoat](https://github.com/OWASP/railsgoat) source code:

```bash
noir scan railsgoat -f oas3 -o railsgoat-openapi.json
```

The generated file begins as follows:

```json
{
  "openapi": "3.0.3",
  "info": {
    "title": "Generated by Noir",
    "version": "1.0.0"
  },
  "servers": [
    {
      "url": "http://localhost"
    }
  ],
  "paths": {
    "/api/v1/mobile/1": {
      "get": {
        "responses": {
          "200": {
            "description": "Successful response",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object"
                }
              }
            }
          }
        },
        "parameters": [
          {
            "name": "class",
            "in": "query",
            "required": false,
            "schema": {
              "type": "string"
            }
          }
        ],
        "x-noir-unmapped-path-params": [
          "id"
        ]
      }
    },
```

Import the document with the ZAP [OpenAPI Support](https://www.zaproxy.org/docs/desktop/addons/openapi-support/) add-on or the Burp Suite OpenAPI Parser extension (see [General Tools](#general-tools)). The proxy adds every endpoint to its site tree, so you can run the tests in this section against them. Noir replaces each path parameter with a sample value, so a route with an `:id` placeholder appears as `/api/v1/mobile/1`, and keeps the original names under `x-noir-unmapped-path-params`. Use these when testing for [API Broken Object Level Authorization](02-API_Broken_Object_Level_Authorization.md).

### Port Scanning

API servers are often deployed on non-standard ports, or alongside other exposed services (internal admin panels, gRPC or WebSocket listeners, debug/metrics endpoints) that a documentation-only review would miss. [naabu](https://github.com/projectdiscovery/naabu) is a fast port scanner that can quickly enumerate open ports across the identified hosts, and can pipe its results directly into Nmap for service detection on just the ports found open:

```bash
naabu -p - -rate 2000 -c 50 -retries 2 -warm-up-time 1 -silent -host api.example.com -nmap-cli 'nmap -sV -oX scan.xml'
```

Running this scan first, and Nmap's slower full service-detection scan only against the ports naabu reports as open, considerably reduces total scan time compared to a direct full-range Nmap scan. See [Improving Port Scans Against API Servers](https://danaepp.com/improving-port-scans-against-api-servers) for further tuning guidance specific to API targets, including why CONNECT scans can outperform SYN scans under high concurrency, and how to avoid missing services due to rate-limiting or firewalling.

Also see [Attack Surface Identification](../01-Information_Gathering/04-Attack_Surface_Identification.md) for further discussion of non-standard port discovery.

### Active Fuzzing

Active Fuzzing involves using tools with wordlists and filtering requests results to bruteforce endpoint discovery.

After endpoint and parameter discovery, use collected request values to optimize value-level fuzzing:

- Compare observed values to identify likely valid versus invalid ranges and formats.
- Start with marginal invalid values (for example `0` for fields that are always positive integers).
- Look for sequences so you can test values outside the range currently allocated to the authenticated user.

#### Kiterunner

[KiteRunner](https://github.com/assetnote/kiterunner) is a tool that performs traditional content discovery and bruteforcing routes/endpoints in modern applications and APIs.

```console
kr [scan|brute] <input> [flags]
```

To scan a target for APIs using a wordlist we can:

```console
kr scan https://example.com/api -w /usr/share/wordlists/apis/routes-large.kite --fail-status-codes 404,403
```

#### FFUF/DirBuster/GoBuster

All three of FFUF, DirBuster, and GoBuster are designed to discover hidden paths and files on web servers through brute-forcing techniques. All three use customizable wordlists to generate requests to the target web server, attempting to identify valid directories and files. All three support multi-threaded or highly efficient processing to speed up the brute-forcing process.

Some common wordlist files for APIs include: [SecLists](https://github.com/danielmiessler/SecLists) in the Discovery/Web-Content/API section, [GraphQL Wordlist](https://github.com/Escape-Technologies/graphql-wordlist), and [Assetnote](https://wordlists.assetnote.io/).

GoBuster Example:

`gobuster dir -u <target url> -w <wordlist file>`

#### Authenticated Fuzzing

When fuzzing authenticated APIs, replay the same authentication and session handling that the target expects. Include custom tokens, non-standard authorization headers, signed request metadata, or cookies as required, otherwise tools may produce false negatives by never reaching the application logic. If the mechanism uses dynamic fields (for example timestamps, nonces, or body-bound signatures), recompute those values for each mutated request, typically through pre-request scripting or proxy/request interceptors.

## References

### OWASP Resources

- [REST Assessment Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/REST_Assessment_Cheat_Sheet.html)

### Books

- Corey J. Ball - "Hacking APIs : breaking web application programming interfaces", No Starch, 2022 - ISBN-13: 978-1-7185-0244-4
- Confidence Staveley - "API Security for White Hat Hackers, Packt, 2024 - ISBN 978-1-80056-080-2  
