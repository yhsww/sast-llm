# Weak Password Change or Reset Functionalities

|ID          |
|------------|
|WSTG-ATHN-09|

## Summary

For any application that requires the user to authenticate with a password, there must be a mechanism by which the user can regain access to their account if they forget their password. Although this can sometimes be a manual process that involves contacting the owner of the website or a support team, users are frequently allowed to carry out a self-service password reset, and to regain access to their account by providing some other evidence of their identity.

As this functionality provides a direct route to compromise the user's account, it is crucial that it is implemented securely.

## Test Objectives

- Determine whether the password change and reset functionality allows accounts to be compromised.

## How to Test

### Information Gathering

The first step is to gather information about what mechanisms are available to allow the user to reset their password on the application. If there are multiple interfaces on the same site (such as a web interface, mobile application, and API) then these should all be reviewed, in case they provide different functionality.

Once this has been established, determine what information is required in order for a user to initiate a password reset. This can be the username or email address (both of which may be obtained from public information), but it could also be an internally-generated user ID.

### General Concerns

Regardless of the specific methods used to reset passwords, there are a number of common areas that need to be considered:

- Is the password reset process weaker than the authentication process?

  The password reset process provides an alternative mechanism to access a user's account, and so should be at least as secure as the usual authentication process. However, it can provide an easier way to compromise the account, especially if it uses weaker authentication factors such as security questions.

  Additionally, the password reset process may bypass the requirement to use Multi-Factor Authentication (MFA), which can substantially reduce the security of the application.

- Is there rate limiting or other protection against automated attacks?

  As with any authentication mechanism, the password reset process should have protection against automated or brute-force attacks. There are a variety of different methods that can be used to achieve this, such as rate limiting or the use of CAPTCHA. These are particularly important on functionality that triggers external actions (such as sending an email or SMS), or when the user is entering a password reset token.

  It is also possible to protect against brute-force attacks by locking out the account from the password reset process after a certain number of consecutive attempts. This could also prevent a legitimate user from being able to reset their password and regain access to their account, however.

- Is it vulnerable to common attacks?

  As well as the specific areas discussed in this guide, it's also important to check for other common vulnerabilities such as SQL injection or cross-site scripting.

- Does the reset process allow user enumeration?

  See the [Account Enumeration](../03-Identity_Management/04-Account_Enumeration_and_Guessable_User_Account.md) guide for further information.

### Email - New Password Sent

In this model, the user is sent a new password via email once they have proved their identity. This is considered less secure for two main reasons:

- The password is sent to the user in an unencrypted form.
- The password for the account is changed when the request is made, effectively locking the user out of their account until they receive the email. By making repeated requests, it is possible to prevent a user from being able to access their account.

Where this approach is used, the following areas should be reviewed:

- Is the user forced to change the password on initial login?

  The new password is sent over unencrypted email, and may sit in the user's inbox indefinitely if they don't delete the email. As such, the user should be required to change the password as soon as they log in for the first time.

- Is the password securely generated?

  The password should be generated using a Cryptographically Secure Pseudo-Random Number Generator (CSPRNG), and should be sufficiently long to prevent password guessing or brute-force attacks. For a secure user-friendly experience, it should be generated using a secure passphrase-style approach (i.e, combining multiple words), rather than a string of random characters.

- Is the user's existing password sent to them?

  Rather than generating a new password for the user, some applications will send the user their existing password. This is a very insecure approach, as it exposes their current password over unencrypted email. Additionally, if the site is able to recover the existing password, this implies that passwords are either stored using reversible encryption, or (more likely) in unencrypted plain text, both of which represent a serious security weakness.

- Are the emails sent from a domain with anti-spoofing protection?

  The domain should implement SPF, DKIM, and DMARC to prevent attackers from spoofing emails from it, which could be used as part of a social engineering attack.

- Is email considered sufficiently secure?

  Emails are typically sent unencrypted, and in many cases the user's email account will not be protected by MFA. It may also be shared between multiple individuals, particularly in a corporate environment.

  Consider whether email-based password reset functionality is appropriate, based on the context of the application that is being tested.

### Email - Link Sent

In this model, the user is emailed a link that contains a token. They can then click this link, and are prompted to enter a new password on the site. This is the most common approach used for password reset, but is more complex to implement than the previously discussed approach. The key areas to test are:

- Does the link use HTTPS?

  If the token is sent over unencrypted HTTP, it may be possible for an attacker to intercept it.

- Can the link be used multiple times?

  Links should expire after they are used, otherwise they provide a persistent backdoor for the account.

- Does the link expire if it remains unused?

  Links should be time limited. Exactly how long is appropriate will depend on the site, but it should rarely be more than an hour.

- Is the token sufficiently long and random?

  The security of the process is entirely reliant on an attacker not being able to guess or brute-force a token. The tokens should be generated with a Cryptographically Secure Pseudo-Random Number Generator (CSPRNG), and should be sufficiently long that it is impractical for an attacker to guess or brute-force. At least 128 bits (or 32 hex characters) is a sufficient minimum to make such an online attack impractical.

  Tokens should never be generated based on known values, such as by taking the MD5 hash of the user's email with `md5($email)`, or using GUIDs which may use insecure PRNG functions, or may not even be random depending on the type.

  Testers should also verify how password reset tokens are stored on the server. If reset tokens are stored in plaintext in the database, an attacker who gains database access may be able to reuse them to reset user passwords. A more secure implementation stores a hashed version of the token and compares the hash during validation.

  An alternative approach to random tokens is to use a cryptographically signed token such as a JWT. In this case, the usual JWT checks should be carried out (is the signature verified, can the "nONe" algorithm be used, can the HMAC key be brute-forced, etc). See the [Testing JSON Web Tokens](../06-Session_Management/10-JSON_Web_Tokens.md) guide for further information.

- Does the link contain a user ID?

  Sometimes the password reset link may include a user ID as well as a token, such as `reset.php?userid=1&token=123456`. In this case, it may be possible to modify the `userid` parameter to reset other users' passwords.

- Can you inject a different host header?

  If the application trusts the value of the `Host` header and uses this to generate the password reset link, it may be possible to steal tokens by injecting a modified `Host` header into the request. See the [Host Header Injection](../07-Injection/17-Host_Header_Injection.md) guide for further information.

- Is the link exposed to third parties?

  Test whether the reset token can be exposed through the HTTP `Referer` header when the reset page loads third-party resources.

  When a password reset link contains the token in the URL, such as `https://example.com/reset?token=ABC123`, the token may be included in the HTTP `Referer` header when the page loads external resources such as analytics scripts, images, or JavaScript from third-party domains.

  Verify whether the reset token is leaked to external domains by inspecting network requests made by the reset page.

  1. Trigger a password reset request and open the reset link.
  2. Inspect network requests using browser developer tools or an intercepting proxy such as Burp Suite or ZAP.
  3. Identify requests made to external domains.
  4. Check whether the full reset URL, including the token, appears in the `Referer` header of these requests.
  5. Check whether the reset page sets an appropriate `Referrer-Policy` response header.

  If third-party domains receive the token, an attacker who controls those resources can capture it and reset the victim's password.

- Are the emails sent from a domain with anti-spoofing protection?

  The domain should implement SPF, DKIM, and DMARC to prevent attackers from spoofing emails from it, which could be used as part of a social engineering attack.

- Is email considered sufficiently secure?

  Emails are typically sent unencrypted, and in many cases the user's email account will not be protected by MFA. It may also be shared between multiple individuals, particularly in a corporate environment.

  Consider whether email-based password reset functionality is appropriate, based on the context of the application that is being tested.

### Tokens Sent Over SMS or Phone Call

Rather than sending a token in an email, an alternative approach is to send it via SMS or an automated phone call, which the user will then enter on the application. The key areas to test are:

- Is the token sufficiently long and random?

  Tokens sent this way are typically shorter, as they are intended to be manually typed by the user, rather than being embedded in a link. It's fairly common for applications to use six numeric digits, which only provides ~20 bits of security (feasible for an online brute-force attack), rather than the typically longer email token.

  This makes it much more important that the password reset functionality is protected against brute-force attacks.

- Can the token be used multiple times?

  Tokens should be invalidated after they are used, otherwise they provide a persistent backdoor for the account.

- Does the token expire if it remains unused?

  As the shorter tokens are more susceptible to brute-force attacks, a shorter expiration time should be implemented to limit the window available for an attacker to carry out an attack.

- Are appropriate rate limiting and restrictions in place?

  Sending an SMS or triggering an automated phone call to a user is significantly more disruptive than sending an email, and could be used to harass a user, or even carry out a denial of service attack against their phone. The application should implement rate limiting to prevent this.

  Additionally, SMS messages and phone calls often incur financial costs for the sending party. If an attacker is able to cause a large number of messages to be sent, this could result in significant costs for the website operator. This is especially true if they are sent to international or premium rate numbers. However, allowing international numbers may be a requirement of the application.

- Is SMS or a phone call considered sufficiently secure?

  [A variety of attacks](https://www.ncsc.gov.uk/guidance/protecting-sms-messages-used-in-critical-business-processes#section_4) have been demonstrated that would allow an attacker to effectively hijack SMS messages, there are conflicting views about whether SMS is sufficiently secure to be used as an authentication factor.

  It is usually possible to answer an automated phone call with physical access to a device, without needing any kind of PIN or fingerprint to unlock the phone. In some circumstances (such as a shared office environment), this could allow an internal attacker to trivially reset another user's password by walking over to their desk when they are out of office.

  Consider whether SMS or automated phone calls are appropriate, based on the context of the application that is being tested.

### Security Questions

Rather than sending them a link or new password, security questions can be used as a mechanism to authenticate the user. This is considered to be a weak approach, and should not be used if better options are available.

See the [Weak Security Questions](08-Weak_Security_Question_Answer.md) guide for further information.

### Authenticated Identity and Configuration Changes

If the application supports the ability to modify an account's primary identifier (such as an email address or phone number) that is utilized in the password change and reset functionalities the user should be forced to re-authenticate. When the primary identifier used in the password change functionality is able to be modified without re-authentication it allows the re-authentication in the password change functionality to be bypassed. Overall, anything that impacts the security of the account (email, MFA, backup settings, etc.) should require re-authentication before it can be modified.

For example: An application has a password reset flow that sends a reset link to the account's email address. The application also requires re-authentication if the password is attempted to be changed from the perspective of an authenticated user. If an attacker gains access to the account (via a stolen cookie, physical access to the computer, etc.) and changes the account's email address without needing to re-authenticate, then the password reset flow can be used to change the password, bypassing the authenticated password change flow.

### Authenticated Password Changes

Once the user has proved their identity (either through a password reset link, a recovery code, or by logging in on the application) they should be able to change their password. The key areas to test are:

- When setting the password, can you specify the user ID?

  If the user ID is included in the password reset request and is not validated, it may be possible to modify it and change other users' passwords.

- Is the user required to re-authenticate?

  If a logged-in user tries to change their password, they should be asked to re-authenticate with their current password in order to protect against an attacker gaining temporary access to an unattended session. If the user has MFA enabled, then they would typically re-authenticate with that, rather than their password.

- Is the password change form vulnerable to CSRF?

  If the user isn't required to re-authenticate, then it may be possible to carry out a CSRF attack against the password reset form, allowing their account to be compromised. See the [Cross-Site Request Forgery](../06-Session_Management/05-Cross_Site_Request_Forgery.md) guide for further information.

- Is a strong and effective password policy applied?

  The password policy should be consistent across the registration, password change, and password reset functionality. See the [Weak Authentication Methods](07-Weak_Authentication_Methods.md) guide for further information.

## Remediation

Ensure that:

- Password change and reset flows are at least as strong as normal authentication and cannot bypass MFA.
- Reset tokens are high-entropy, single-use, short-lived, and stored hashed; reset links use HTTPS and are not built from an untrusted `Host` header.
- Reset pages do not leak tokens to third parties via the `Referer` header; set an appropriate `Referrer-Policy` and avoid third-party resources on those pages. See [Other HTTP Security Header Misconfigurations](../02-Configuration_and_Deployment_Management/14-Other_HTTP_Security_Header_Misconfigurations.md).
- Rate limiting, re-authentication for sensitive account changes, CSRF protection, and a consistent password policy are applied.

## References

- [OWASP Forgot Password Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Forgot_Password_Cheat_Sheet.html)
