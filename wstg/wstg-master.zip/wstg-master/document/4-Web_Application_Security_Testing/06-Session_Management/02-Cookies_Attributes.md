# Cookies Attributes

|ID          |
|------------|
|WSTG-SESS-02|

## Summary

Web Cookies (herein referred to as cookies) are often a key attack vector for malicious users (typically targeting other users) and the application should always take due diligence to protect cookies.

HTTP is a stateless protocol, meaning that it doesn't hold any reference to requests being sent by the same user. In order to fix this issue, sessions were created and appended to HTTP requests. Browsers, as discussed in [testing browser storage](../11-Client-side/12-Browser_Storage.md), contain a multitude of storage mechanisms. In that section of the guide, each is discussed thoroughly.

The most used session storage mechanism in browsers is cookie storage. Cookies can be set by the server, by including a [`Set-Cookie`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie) header in the HTTP response or via JavaScript. Cookies can be used for a multitude of reasons, such as:

- session management
- personalization
- tracking

In order to secure cookie data, the industry has developed means to help lock down these cookies and limit their attack surface. Over time cookies have become a preferred storage mechanism for web applications, as they allow great flexibility in use and protection.

The means to protect the cookies are:

- [Cookie Attributes](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies#Creating_cookies)
- [Cookie Prefixes](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies#Cookie_prefixes)

## Test Objectives

- Ensure that the proper security configuration is set for cookies.

## How to Test

Below, a description of every attribute and prefix will be discussed. The tester should validate that they are being used properly by the application. Cookies can be reviewed by using an [intercepting proxy](#intercepting-proxy), or by reviewing the browser's cookie jar.

### Cookie Attributes

#### Secure Attribute

The [`Secure`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie#Secure) attribute tells the browser to only send the cookie if the request is being sent over a secure channel such as `HTTPS`. This will help protect the cookie from being passed in unencrypted requests. If the application can be accessed over both `HTTP` and `HTTPS`, an attacker could be able to redirect the user to send their cookie as part of non-protected requests.

#### HttpOnly Attribute

The [`HttpOnly`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie#HttpOnly) attribute is used to help prevent attacks such as session leakage, since it does not allow the cookie to be accessed via a client-side script such as JavaScript.

> This doesn't limit the whole attack surface of XSS attacks, as an attacker could still send request in place of the user, but limits immensely the reach of XSS attack vectors.

#### Domain Attribute

The [`Domain`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies#Scope_of_cookies) attribute is used to compare the cookie's domain against the domain of the server for which the HTTP request is being made. If the domain matches or if it is a subdomain, then the [`path`](#path-attribute) attribute will be checked next.

Only hosts that belong to the specified domain can set a cookie for that domain. Additionally, the `domain` attribute cannot be a top level domain (such as `.gov` or `.com`) to prevent servers from setting arbitrary cookies for another domain (such as setting a cookie for `owasp.org`). If the domain attribute is not set, then the hostname of the server that generated the cookie is used as the default value of the `domain`.

For example, if a cookie is set by an application at `app.mydomain.com` with no domain attribute set, then the cookie would be resubmitted for all subsequent requests for `app.mydomain.com`, but not its subdomains (such as `hacker.app.mydomain.com`), or to `otherapp.mydomain.com`. (However, older versions of Edge/IE behave differently, and _do_ send these cookies to subdomains.) If a developer wanted to loosen this restriction, then they could set the `domain` attribute to `mydomain.com`. In this case the cookie would be sent to all requests for `app.mydomain.com` and `mydomain.com` subdomains, such as `hacker.app.mydomain.com`, and even `bank.mydomain.com`. If there was a vulnerable server on a subdomain (for example, `otherapp.mydomain.com`) and the `domain` attribute has been set too loosely (for example, `mydomain.com`), then the vulnerable server could be used to harvest cookies (such as session tokens) across the full scope of `mydomain.com`.

#### Path Attribute

The [`Path`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies#Scope_of_cookies) attribute plays a major role in setting the scope of the cookies in conjunction with the [`domain`](#domain-attribute). In addition to the domain, the URL path that the cookie is valid for can be specified. If the domain and path match, then the cookie will be sent in the request. Just as with the domain attribute, if the path attribute is set too loosely, then it could leave the application vulnerable to attacks by other applications on the same server. For example, if the path attribute was set to the web server root `/`, then the application cookies will be sent to every application within the same domain (if multiple application reside under the same server). A couple of examples for multiple applications under the same server:

- `path=/bank`
- `path=/private`
- `path=/docs`
- `path=/docs/admin`

#### Expires Attribute

The [`Expires`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies#Permanent_cookies) attribute is used to:

- set persistent cookies
- limit lifespan if a session lives for too long
- remove a cookie forcefully by setting it to a past date

Unlike [session cookies](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies#Session_cookies), persistent cookies will be used by the browser until the cookie expires. Once the expiration date has exceeded the time set, the browser will delete the cookie.

#### SameSite Attribute

The [`SameSite`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies#SameSite_cookies) attribute can be used to assert whether a cookie should be sent along with cross-site requests. This feature allows the server to mitigate the risk of cross-site information leakage. In some cases, it is used too as a risk reduction (or defense in depth mechanism) strategy to prevent [cross-site request forgery](05-Cross_Site_Request_Forgery.md) attacks. This attribute can be configured in three different modes:

- `Strict`
- `Lax`
- `None`

`SameSite` compares [sites](https://developer.mozilla.org/en-US/docs/Glossary/Site), not origins. A site is the scheme and registrable domain, such as `https://mydomain.com`, so `https://app.mydomain.com` and `https://otherapp.mydomain.com` are the same site even though they are different origins. `SameSite` does not restrict requests between them. If an attacker controls any subdomain of the same site, for example through XSS or a [subdomain takeover](../02-Configuration_and_Deployment_Management/10-Subdomain_Takeover.md), they can send requests to the application that include its cookies, even `Strict` ones. When you assess how much protection `SameSite` provides, consider every subdomain of the site.

##### Strict Value

The `Strict` value is the most restrictive usage of `SameSite`. The browser sends the cookie only on requests that come from the same site that set it, and never on cross-site requests, including top-level navigations such as following a link from another site. This value is especially recommended for actions performed within the same site. However, it can affect the navigation experience with some session management systems. When a signed-in user follows a link to the application from another site, such as a webmail client, the browser does not send the cookie on that first request, so the user appears to be signed out. The cookie is sent again on the next same-site request, such as when the user follows a link within the application.

##### Lax Value

The `Lax` value is less restrictive than `Strict`. It allows the cookie to be sent on cross-site _top-level navigations_ that use a "safe" HTTP method (in practice, `GET`) - for example, when a user follows a link from another site. It does __not__ send the cookie on cross-site _subresource_ requests, such as those triggered by `<img>`, `<script>`, or `<iframe>` tags, `fetch()`, or `XMLHttpRequest`, and it does not send the cookie on cross-site navigations that use `POST` or other unsafe methods.

Starting in 2020, Chromium-based browsers (Chrome, Edge, Opera) treat any cookie set __without__ an explicit `SameSite` attribute as `SameSite=Lax` by default. Firefox and Safari do not apply that default. In those browsers a cookie that omits `SameSite` remains eligible to be sent on cross-site requests, subject instead to their own tracking-prevention and third-party-cookie controls (Firefox's Enhanced Tracking Protection / Total Cookie Protection, Safari's Intelligent Tracking Prevention). Note that omitting the attribute is not the same as setting [`SameSite=None`](#none-value), which is an explicit value that additionally requires the [`Secure`](#secure-attribute) attribute in order to be accepted. Those tracking-prevention controls are privacy mechanisms rather than a substitute for setting `SameSite`, and they behave differently from an explicit `SameSite=Lax` restriction. Testers should not assume a cookie is protected against CSRF just because a cross-site request appears to be blocked in Firefox or Safari - verify the actual `Set-Cookie` header rather than inferring protection from observed browser behavior.

When a Chromium-based browser applies `Lax` by default, it uses a [more permissive version of `Lax`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie#samesitesamesite-value): a cookie without a `SameSite` attribute is still sent on cross-site top-level `POST` requests for two minutes after it is set. Cookies that explicitly set `SameSite=Lax` do not get this exception. This means a cross-site `POST` sent shortly after the user signs in can still carry a session cookie that has no `SameSite` attribute.

##### None Value

The `None` value specifies that the browser will send the cookie in all contexts, including cross-site requests (the normal behavior before the implementation of `SameSite`). A cookie that sets `SameSite=None` must also set the [`Secure`](#secure-attribute) attribute, _e.g._ `SameSite=None; Secure`. Chromium-based browsers and Firefox reject a `SameSite=None` cookie without `Secure`, so the cookie is not stored at all. Safari does not enforce this requirement (see the [browser compatibility table on MDN](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie#browser_compatibility)).

### Cookie Prefixes

By design cookies do not have the capabilities to guarantee the integrity and confidentiality of the information stored in them. Those limitations make it impossible for a server to have confidence about how a given cookie's attributes were set at creation. In order to give the servers such features in a backwards-compatible way, the industry has introduced the concept of [`Cookie Name Prefixes`](https://tools.ietf.org/html/draft-ietf-httpbis-cookie-prefixes-00) to facilitate passing such details embedded as part of the cookie name.

#### Host Prefix

The [`__Host-`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies#Cookie_prefixes) prefix expects cookies to fulfill the following conditions:

  1. The cookie must be set with the [`Secure` attribute](#secure-attribute).
  2. The cookie must be set from a URI considered secure by the user agent.
  3. Sent only to the host who set the cookie and MUST NOT include any [`Domain` attribute](#domain-attribute).
  4. The cookie must be set with the [`Path` attribute](#path-attribute) with a value of `/` so it would be sent with every request to the host.

For this reason, the cookie `Set-Cookie: __Host-SID=12345; Secure; Path=/` would be accepted while any of the following ones would always be rejected:
`Set-Cookie: __Host-SID=12345`
`Set-Cookie: __Host-SID=12345; Secure`
`Set-Cookie: __Host-SID=12345; Domain=site.example`
`Set-Cookie: __Host-SID=12345; Domain=site.example; Path=/`
`Set-Cookie: __Host-SID=12345; Secure; Domain=site.example; Path=/`

#### Secure Prefix

The [`__Secure-`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies#Cookie_prefixes) prefix is less restrictive and can be introduced by adding the case-sensitive string `__Secure-` to the cookie name. Any cookie that matches the prefix `__Secure-` would be expected to fulfill the following conditions:

  1. The cookie must be set with the `Secure` attribute.
  2. The cookie must be set from a URI considered secure by the user agent.

### Strong Practices

Based on the application needs, and how the cookie should function, the attributes and prefixes must be applied. The more the cookie is locked down, the better.

Putting all this together, we can define the most secure cookie attribute configuration as: `Set-Cookie: __Host-SID=<session token>; path=/; Secure; HttpOnly; SameSite=Strict`.

## Tools

### Intercepting Proxy

- [Zed Attack Proxy (ZAP)](https://www.zaproxy.org)
- [Web Proxy Burp Suite](https://portswigger.net)

### Browser Plug-in

- Browser developer tools (Application or Storage panel)
- ["FireSheep" for FireFox](https://github.com/codebutler/firesheep)
- ["Cookie-Editor" for Chrome](https://chromewebstore.google.com/detail/cookie-editor/hlkenndednhfkekhgcdicdfddnkalmdm)
- ["Cookiebro - Cookie Manager" for FireFox](https://addons.mozilla.org/en-US/firefox/addon/cookiebro/)

## References

- [RFC 2965 - HTTP State Management Mechanism](https://tools.ietf.org/html/rfc2965)
- [RFC 2616 - Hypertext Transfer Protocol - HTTP 1.1](https://tools.ietf.org/html/rfc2616)
- [Cookies: HTTP State Management Mechanism - draft-ietf-httpbis-rfc6265bis](https://datatracker.ietf.org/doc/draft-ietf-httpbis-rfc6265bis/)
- [The important "expires" attribute of Set-Cookie](https://seckb.yehg.net/2012/02/important-expires-attribute-of-set.html)
- [HttpOnly Session ID in URL and Page Body](https://seckb.yehg.net/2012/06/httponly-session-id-in-url-and-page.html)
- [Internet Explorer Cookie Internals (FAQ)](https://learn.microsoft.com/en-gb/archive/blogs/ieinternals/internet-explorer-cookie-internals-faq)
