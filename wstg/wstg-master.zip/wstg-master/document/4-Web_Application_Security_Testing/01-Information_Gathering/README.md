# 4.1 Information Gathering

4.1.0 [Information Gathering Overview](00-Information_Gathering_Overview.md)

4.1.1 [Conduct Search Engine Reconnaissance for Information Leakage](01-Conduct_Search_Engine_Reconnaissance_for_Information_Leakage.md)

4.1.2 [Fingerprint Web Server](02-Fingerprint_Web_Server.md)

4.1.3 [Review Webserver Metafiles for Information Leakage](03-Review_Webserver_Metafiles_for_Information_Leakage.md)

4.1.4 [Attack Surface Identification](04-Attack_Surface_Identification.md)

4.1.5 [Review Web Page Content for Information Leakage](05-Review_Web_Page_Content_for_Information_Leakage.md)

4.1.6 [Identify Application Entry Points](06-Identify_Application_Entry_Points.md)

4.1.7 [Map Execution Paths Through Application](07-Map_Execution_Paths_Through_Application.md)

4.1.8 [Fingerprint Web Application Framework](08-Fingerprint_Web_Application_Framework.md)

4.1.9 [Fingerprint Web Application](09-Fingerprint_Web_Application.md)

4.1.10 [Map Application Architecture](10-Map_Application_Architecture.md)
