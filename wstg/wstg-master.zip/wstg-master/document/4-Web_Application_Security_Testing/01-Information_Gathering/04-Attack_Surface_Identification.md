# Attack Surface Identification

|ID          |
|------------|
|WSTG-INFO-04|

## Summary

Identifying the attack surface of a web application involves discovering all applications, domains, virtual hosts, and externally exposed services associated with the target infrastructure. This process extends beyond identifying hosted applications and includes DNS enumeration, subdomain discovery, virtual host analysis, non-standard ports, and the review of digital certificates and Certificate Transparency logs.

With the proliferation of virtual hosting and shared infrastructure, the traditional 1:1 relationship between an IP address and a web server has largely disappeared. A single IP address may host multiple applications across different domains, environments, or administrative interfaces. Failing to identify these assets can result in incomplete assessments and overlooked vulnerabilities.

Security professionals are sometimes given a set of IP addresses as a target to test. It is arguable that this scenario is more akin to a penetration test-type engagement, but in any case it is expected that such an assignment would test all web applications accessible through this target. The problem is that the given IP address hosts an HTTP service on port 80, but if a tester should access it by specifying the IP address (which is all they know) it reports "No web server configured at this address" or a similar message. But that system could "hide" a number of web applications, associated to unrelated symbolic (DNS) names. Obviously, the extent of the analysis is deeply affected depending on whether the tester tests all the applications or only tests the applications that they are aware of.

Sometimes, the target specification is richer. The tester may be given a list of IP addresses and their corresponding symbolic names. Nevertheless, this list might convey partial information, i.e., it could omit some symbolic names and the client may not even be aware of that (this is more likely to happen in large organizations).

Other issues affecting the scope of the assessment are represented by web applications published at non-obvious URLs (e.g., `https://www.example.com/some-strange-URL`), which are not referenced elsewhere. This may happen either by error (due to misconfigurations), or intentionally (for example, unadvertised administrative interfaces).

To address these issues, a comprehensive attack surface identification process must be performed.

## Test Objectives

- Enumerate all web applications within scope.
- Identify DNS names, domains, and virtual hosts associated with the target.
- Discover additional domains and subdomains using passive and active DNS techniques.
- Analyze digital certificates and Certificate Transparency logs for additional hostnames.

## How to Test

Web application discovery is a process that aims to identify web applications on a given infrastructure. The latter is usually specified as a set of IP addresses (maybe a net block), but may consist of a set of DNS symbolic names or a mix of the two. This information is handed out prior to the execution of an assessment, be it a classic-style penetration test or an application-focused assessment. In both cases, unless the rules of engagement specify otherwise (e.g., test only the application located at the URL `https://www.example.com/`), the assessment should strive to be the most comprehensive in scope, i.e. it should identify all the applications accessible through the given target. The following examples examine a few techniques that can be employed to achieve this goal.

> Some of the following techniques apply to Internet-facing web servers, namely DNS and reverse-IP web-based search services and the use of search engines. Examples make use of private IP addresses (such as `192.168.1.100`), which, unless indicated otherwise, represent *generic* IP addresses and are used only for anonymity purposes.

There are three factors influencing how many applications are related to a given DNS name (or an IP address):

1. **Different Base URL**

    The obvious entry point for a web application is `www.example.com`, i.e., with this shorthand notation we think of the web application originating at `https://www.example.com/` (the same applies for HTTPS). However, even though this is the most common situation, there is nothing forcing the application to start at `/`.

    For example, the same symbolic name may be associated to three web applications such as: `https://www.example.com/app1` `https://www.example.com/app2` `https://www.example.com/app3`

    In this case, the URL `https://www.example.com/` would not be associated with a meaningful page. The three applications would remain **hidden** unless the tester explicitly knows how to access them, i.e., the tester knows *app1*, *app2* or *app3*. There is usually no need to publish web applications in this way, unless the owner doesn’t want them to be accessible in a standard way, and is prepared to inform the users about their exact location. This doesn’t mean that these applications are secret, just that their existence and location is not explicitly advertised.

2. **Non-standard Ports**

    While web applications usually live on port 80 (HTTP) and 443 (HTTPS), there is nothing fixed or mandatory about these port numbers. In fact, web applications may be associated with arbitrary TCP ports, and can be referenced by specifying the port number as follows: `http[s]://www.example.com:port/`. For example, `https://www.example.com:20000/`.

3. **Virtual Hosts**

    DNS allows a single IP address to be associated with one or more symbolic names. For example, the IP address `192.168.1.100` might be associated to DNS names `www.example.com`, `helpdesk.example.com`, `webmail.example.com`. It is not necessary that all the names belong to the same DNS domain. This 1-to-N relationship may be reflected to serve different content by using so called virtual hosts. The information specifying the virtual host we are referring to is embedded in the HTTP 1.1 [Host header](https://datatracker.ietf.org/doc/html/rfc7230#section-5.4).

    One would not suspect the existence of other web applications in addition to the obvious `www.example.com`, unless they know of `helpdesk.example.com` and `webmail.example.com`.

### Approaches to Address Issue 1 - Non-standard URLs

There is no way to fully ascertain the existence of non-standard-named web applications. Being non-standard, there are no fixed criteria governing the naming convention, however there are a number of techniques that the tester can use to gain some additional insight.

First, if the web server is mis-configured and allows directory browsing, it may be possible to spot these applications. Vulnerability scanners may help in this respect.

Second, these applications may be referenced by other web pages and there is a chance that they have been spidered and indexed by web search engines. If testers suspect the existence of such **hidden** applications on `www.example.com` they could search using the *site* operator and examining the result of a query for `site: www.example.com`. Among the returned URLs there could be one pointing to such a non-obvious application.

Another option is to probe for URLs which might be likely candidates for non-published applications. For example, a web mail frontend might be accessible from URLs such as `https://www.example.com/webmail`, `https://webmail.example.com/`, or `https://mail.example.com/`. The same holds for administrative interfaces, which may be published at hidden URLs (for example, a Tomcat administrative interface), and yet not referenced anywhere. So doing a bit of dictionary-style searching (or "intelligent guessing") could yield some results. Vulnerability scanners may help in this respect.

### Approaches to Address Issue 2 - Non-standard Ports

It is easy to check for the existence of web applications on non-standard ports. A port scanner such as Nmap is capable of performing service recognition by means of the `-sV` option, and will identify http[s] services on arbitrary ports. What is required is a full scan of the whole 64k TCP port address space.

For example, the following command will look up, with a TCP connect scan, all the open ports on IP `192.168.1.100` and will try to determine what services are bound to them (only *essential* switches are shown - Nmap features a broad set of options, whose discussion is out of scope):

`nmap -Pn -sT -sV -p0-65535 192.168.1.100`

It is sufficient to examine the output and look for HTTP or the indication of TLS-wrapped services (which should be probed to confirm that they are HTTPS). For example, the output of the previous command could look like:

```bash
Interesting ports on 192.168.1.100:
(The 65527 ports scanned but not shown below are in state: closed)
PORT      STATE SERVICE     VERSION
22/tcp    open  ssh         OpenSSH 3.5p1 (protocol 1.99)
80/tcp    open  http        Apache httpd 2.0.40 ((Red Hat Linux))
443/tcp   open  ssl         OpenSSL
901/tcp   open  http        Samba SWAT administration server
1241/tcp  open  ssl         Nessus security scanner
3690/tcp  open  unknown
8000/tcp  open  http-alt?
8080/tcp  open  http        Apache Tomcat/Coyote JSP engine 1.1
```

From this example, one can see that:

- There is an Apache HTTP server running on port 80.
- It looks like there is an HTTPS server on port 443 (but this needs to be confirmed, for example, by visiting `https://192.168.1.100` with a browser).
- On port 901 there is a Samba SWAT web interface.
- The service on port 1241 is not HTTPS, but is the TLS-wrapped Nessus daemon.
- Port 3690 features an unspecified service (Nmap gives back its *fingerprint* - here omitted for clarity - together with instructions to submit it for incorporation in the Nmap fingerprint database, provided you know which service it represents).
- Another unspecified service on port 8000; this might possibly be HTTP, since it is not uncommon to find HTTP servers on this port. Let's examine this issue:

```bash
$ ncat 192.168.10.100 8000
GET / HTTP/1.0

HTTP/1.0 200 OK
pragma: no-cache
Content-Type: text/html
Server: MX4J-HTTPD/1.0
expires: now
Cache-Control: no-cache

<html>
...
```

This confirms that in fact it is an HTTP server. Alternatively, testers could have visited the URL with a web browser; or used the GET or HEAD Perl commands, which mimic HTTP interactions such as the one given above (however HEAD requests may not be honored by all servers).

- Apache Tomcat running on port 8080.

The same task may be performed by vulnerability scanners, but first check that the scanner of choice is able to identify HTTP[S] services running on non-standard ports. For example, Nessus is capable of identifying them on arbitrary ports (provided it is instructed to scan all the ports), and will provide, with respect to Nmap, a number of tests on known web server vulnerabilities, as well as on the TLS/SSL configuration of HTTPS services. As hinted before, Nessus is also able to spot popular applications or web interfaces which could otherwise go unnoticed (for example, a Tomcat administrative interface).

A full 65535-port Nmap scan with service detection can be slow across many hosts. [naabu](https://github.com/projectdiscovery/naabu) is a fast port scanner that can be used to quickly identify open ports across a large host list, and can pipe its results straight into Nmap for service detection on just the open ports it found:

```bash
naabu -p - -rate 2000 -c 50 -retries 2 -warm-up-time 1 -silent -host 192.168.1.100 -nmap-cli 'nmap -sV -oX scan.xml'
```

This combination scans all ports with naabu first, then only runs the slower Nmap service-detection scan against the ports naabu found open, considerably reducing total scan time.

### Approaches to Address Issue 3 - Virtual Hosts

There are a number of techniques which may be used to identify DNS names associated to a given IP address `x.y.z.t`.

#### DNS Enumeration

DNS enumeration aims to identify domains, subdomains, and related DNS records associated with the target organization to expand the assessment scope. DNS enumeration plays a key role in identifying additional virtual hosts mapped to the same IP address. This may reveal development systems, staging environments, legacy services, or administrative interfaces.

Both passive and active techniques can be used.

#### Passive DNS Enumeration

Passive techniques do not directly interact with the target infrastructure and instead rely on publicly available data sources. Examples include:

- Public DNS records (A, AAAA, MX, TXT, NS)
- Reverse DNS lookups (PTR records)
- Search engines
- Passive DNS databases
- Certificate Transparency logs

Passive techniques are preferred during early reconnaissance phases to avoid detection.

[Chaos](https://chaos.projectdiscovery.io/) and its [chaos-client](https://github.com/projectdiscovery/chaos-client) provide access to a curated dataset of subdomains that ProjectDiscovery has already crawled, primarily sourced from public bug bounty program scopes. It can be a useful, fast supplement to passive DNS enumeration for domains it has already indexed, but it requires an API key, only covers domains within its dataset, and should not be relied on as a substitute for active tools such as `subfinder` or `amass` against arbitrary engagement targets.

#### Active DNS Enumeration

Active techniques directly query the target's DNS infrastructure and may generate logs on the target systems. These include:

- Subdomain brute forcing
- DNS zone transfer attempts
- DNS record enumeration using tools

Common tools used for DNS enumeration include:

- `amass`
- `subfinder`
- `dnsrecon`
- `fierce`
- `dig`
- `nslookup`

Example using `dig`:

```bash
dig example.com ANY
```

```text
; <<>> DiG 9.10.6 <<>> example.com ANY
;; QUESTION SECTION:
;example.com.                  IN      ANY

;; ANSWER SECTION:
example.com.            86400   IN      A       93.184.216.34
example.com.            86400   IN      MX      10 mail.example.com.
example.com.            86400   IN      NS      ns1.secure.net.
example.com.            86400   IN      NS      ns2.secure.net.
example.com.            86400   IN      TXT     "v=spf1 -all"
```

Example using `subfinder`:

```bash
subfinder -d example.com -silent
```

```text
www.example.com
dev.example.com
staging.example.com
mail.example.com
api.example.com
```

#### Subdomain Permutation

After an initial set of subdomains has been collected, permutation (or alteration) techniques can generate additional candidates by combining known labels with common prefixes/suffixes or by applying mutations (e.g. `dev-` → `staging-`, inserting numbers, etc.). Tools such as [altdns](https://github.com/infosec-au/altdns), [dnsgen](https://github.com/ProjectAnte/dnsgen), or [gotator](https://github.com/Josue87/gotator) are commonly used for this purpose. Generated candidates should then be resolved (`dnsx` / [MassDNS](https://github.com/blechschmidt/massdns)) and probed (`httpx`).

MassDNS is a high-speed DNS resolver, useful for quickly resolving the large candidate lists produced by permutation tools or wordlist-based brute forcing.

#### DNS Zone Transfers

This technique has limited use nowadays, given the fact that zone transfers are largely not honored by DNS servers. However, it could still be worth attempting. First of all, testers must determine the name servers serving `x.y.z.t`. If a symbolic name is known for `x.y.z.t` (let it be `www.example.com`), its name servers can be determined by means of tools such as `nslookup`, `host`, or `dig`, by requesting DNS NS records.

If no symbolic names are known for `x.y.z.t`, but the target definition contains at least a symbolic name, testers may try to apply the same process and query the name server of that name (hoping that `x.y.z.t` will be served as well by that name server). For example, if the target consists of the IP address `x.y.z.t` and the name `mail.example.com`, determine the name servers for domain `example.com`.

The following example shows how to identify the name servers for `www.owasp.org` by using the `host` command:

```bash
$ host -t ns www.owasp.org
www.owasp.org is an alias for owasp.org.
owasp.org name server ns1.secure.net.
owasp.org name server ns2.secure.net.
```

A zone transfer can now be requested to the name servers for the domain `example.com`. If the tester is fortunate, they may receive a list of the DNS entries for this domain in response. This will include the obvious `www.example.com` and the not-so-obvious `helpdesk.example.com` and `webmail.example.com` (and possibly others). Check all the names returned by the zone transfer and consider all of those which are related to the target being evaluated.

Trying to request a zone transfer for `owasp.org` from one of its name servers:

```bash
$ host -l www.owasp.org ns1.secure.net
Using domain server:
Name: ns1.secure.net
Address: 192.220.124.10#53
Aliases:

Host www.owasp.org not found: 5(REFUSED)
; Transfer failed.
```

#### DNS Inverse Queries

This process is similar to the previous one, but relies on inverse (PTR) DNS records. Rather than requesting a zone transfer, try setting the record type to PTR and issue a query on the given IP address. If the testers are fortunate, they may receive a DNS name entry in response. This technique relies on the existence of IP-to-symbolic name maps, which is not guaranteed.

#### Web-based DNS Searches

This kind of search is akin to DNS zone transfer, but relies on web-based services that enable name-based searches on DNS. One such service is the [Netcraft Search DNS](https://searchdns.netcraft.com/?host) service. The tester may query for a list of names belonging to your domain of choice, such as `example.com`. They will then check whether the names they obtained are pertinent to the target they are examining.

#### Reverse-IP Services

Reverse-IP services are similar to DNS inverse queries, with the difference that the testers query a web-based application instead of a name server. There are a number of such services available. Since they tend to return partial (and often different) results, it is better to use multiple services to obtain a more comprehensive analysis.

- [MxToolbox Reverse IP](https://mxtoolbox.com/ReverseLookup.aspx)
- [DNSstuff](https://www.dnsstuff.com/) (multiple services available)

Internet asset search engines such as [Shodan](https://www.shodan.io/), [Censys](https://censys.com), and [FOFA](https://fofa.info) index internet-connected hosts and services and can also be searched by IP, certificate, or banner content to reveal other hostnames and services hosted on the same address. FOFA in particular has extensive coverage of infrastructure in China and Asia-Pacific, which can complement the coverage of Shodan and Censys. For example, an IP-based FOFA search: `ip="192.168.1.100"`, or a search for a specific title or header: `title="Example App"`. As with the other reverse-IP services above, a free tier with limited queries is available, with paid plans for more comprehensive access.

#### Googling

Following information gathering from the previous techniques, testers can rely on search engines to possibly refine and increment their analysis. This may yield evidence of additional symbolic names belonging to the target, or applications accessible via non-obvious URLs.

For instance, considering the previous example regarding `www.owasp.org`, the tester could query Google and other search engines looking for information (hence, DNS names) related to the newly discovered domains of `webgoat.org`, `webscarab.com`, and `webscarab.net`.

Googling techniques are explained in [Testing: Spiders, Robots, and Crawlers](01-Conduct_Search_Engine_Reconnaissance_for_Information_Leakage.md).

#### Digital Certificates

If the server accepts connections over HTTPS, then the Common Name (CN) and Subject Alternate Name (SAN) on the certificate may contain one or more hostnames. However, if the webserver does not have a trusted certificate, or wildcards are in use, this may not return any valid information.

The CN and SAN can be obtained by manually inspecting the certificate, or through other tools such as OpenSSL:

```sh
openssl s_client -connect 93.184.216.34:443 </dev/null 2>/dev/null | openssl x509 -noout -text | grep -E 'DNS:|Subject:'

Subject: C = US, ST = California, L = Los Angeles, O = Internet Corporation for Assigned Names and Numbers, CN = www.example.org
DNS:www.example.org, DNS:example.com, DNS:example.edu, DNS:example.net, DNS:example.org, DNS:www.example.com, DNS:www.example.edu, DNS:www.example.net
```

#### Certificate Transparency Logs

Certificate Transparency (CT) logs are publicly accessible records of issued TLS certificates. These logs can be searched to identify hostnames and subdomains associated with a target organization, including staging systems, administrative interfaces, legacy systems, or other externally reachable services.

Reviewing CT logs may reveal hostnames that are not directly discoverable through DNS zone transfers, reverse lookups, or search engine queries alone. Testers should extract discovered hostnames and validate them through DNS resolution to determine whether they are active and within the defined scope of the assessment.

When reviewing CT log data, consider:

- Hostnames indicating development, staging, or testing environments.
- Administrative or management interfaces.
- Deprecated or legacy systems that may still be accessible.
- Wildcard certificates that may imply additional undiscovered subdomains.

Information gathered from CT logs should be validated to confirm ownership and relevance before further testing.

Care must be taken to respect scope limitations defined in the engagement.

Discovered assets should be validated and documented before further testing activities.

One common approach to querying CT logs is to use publicly available search portals that aggregate certificate data. For example, a tester may search for certificates issued to `example.com` and review the listed subdomains.

For instance: `https://crt.sh/?q=%25.example.com`

> Note: [crt.sh](https://crt.sh) has occasional periods of downtime or high latency. [Merklemap](https://www.merklemap.com/) and [SSLMate's Cert Spotter](https://sslmate.com/certspotter/) are alternative Certificate Transparency search services worth having as a fallback.

![CT Log Search Example](images/01-ct_logs_example.png)  

*Figure 4.1.4-1: Example of Certificate Transparency log search results.*

The results may list subdomains such as `dev.example.com`, `staging.example.com`, or other hostnames that are not directly referenced from the primary site. Discovered hostnames should be validated through DNS resolution before further testing.

### Example Modern Passive-to-Active Workflow

A common lightweight pipeline used in contemporary assessments:

```bash
# Passive subdomain discovery
subfinder -d example.com -silent | tee subs.txt
amass enum -passive -d example.com -o amass.txt

# Resolve and probe live hosts
cat subs.txt amass.txt | sort -u | dnsx -silent | httpx -silent -title -tech-detect -status-code -o live.txt

# Historical URLs (feed interesting hosts later)
cat live.txt | unfurl domains | sort -u | gau --subs | tee archive-urls.txt

# Screenshot live hosts for visual triage of a large host list
gowitness scan file -f live.txt
```

With a large number of discovered hosts, screenshotting each one provides a quick way to visually triage results, for example spotting login pages, admin panels, default install pages, or error pages without visiting every host manually. [gowitness](https://github.com/sensepost/gowitness) is a current, actively maintained tool for this; `httpx` also supports a built-in `-screenshot` flag for the same purpose without adding another tool to the chain.

Always respect scope, rate limits, and engagement rules of engagement. Validate ownership of newly discovered assets before deeper testing.

## Tools

- DNS lookup tools such as `nslookup`, `dig`, and `host`
- Subdomain enumeration and attack-surface mapping tools:
    - [Amass](https://github.com/owasp-amass/amass) (OWASP project - passive + active, graph output)
    - [subfinder](https://github.com/projectdiscovery/subfinder)
    - [Chaos](https://chaos.projectdiscovery.io/) / [chaos-client](https://github.com/projectdiscovery/chaos-client) (curated subdomain dataset, API key required)
    - [dnsx](https://github.com/projectdiscovery/dnsx)
    - [httpx](https://github.com/projectdiscovery/httpx) (live host probing, tech detection, titles)
    - [gowitness](https://github.com/sensepost/gowitness) (screenshotting for visual triage of live hosts)
    - `dnsrecon`, `fierce`
- Subdomain permutation: [altdns](https://github.com/infosec-au/altdns), [dnsgen](https://github.com/ProjectAnte/dnsgen), [gotator](https://github.com/Josue87/gotator)
- [MassDNS](https://github.com/blechschmidt/massdns) (high-speed resolver for wordlist / permutation output)
- Search engines (Google, Bing, and other major search engines)
- Reverse IP lookup services
- Internet asset search engines: [Shodan](https://www.shodan.io/), [Censys](https://censys.com), [FOFA](https://fofa.info)
- Certificate Transparency search portals: [crt.sh](https://crt.sh), [Merklemap](https://www.merklemap.com/), [SSLMate's Cert Spotter](https://sslmate.com/certspotter/)
- Archive / historical URL collectors: [gau](https://github.com/lc/gau), [waybackurls](https://github.com/tomnomnom/waybackurls), [waymore](https://github.com/xnl-h4ck3r/waymore)
- [Nmap](https://nmap.org/)
- [naabu](https://github.com/projectdiscovery/naabu) (fast port scanning, can pipe results into Nmap)
- [Nessus Vulnerability Scanner](https://www.tenable.com/products/nessus)
- [Nikto](https://github.com/sullo/nikto)
- Content / virtual-host discovery: [ffuf](https://github.com/ffuf/ffuf), [feroxbuster](https://github.com/epi052/feroxbuster), [gobuster](https://github.com/OJ/gobuster)
- Source code analysis for endpoint discovery (white-box or gray-box engagements): [OWASP Noir](https://github.com/owasp-noir/noir), [OWASP Attack Surface Detector](https://owasp.org/projects/attack-surface-detector)
